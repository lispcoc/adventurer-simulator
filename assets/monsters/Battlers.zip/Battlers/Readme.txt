Free for use, just credit JosephSeraph! 
Free to edit and redistribute as well so long as you keep this readme intact & credit me!
--
Please consider donating so I can keep creating resources!
You can do so either by submitting a paypal donation to josephseraph@hotmail.com (sorry I can't provide a direct donation link as they seem to be all expiring really fast!)
Or by supporting me on Patreon! https://www.patreon.com/JosephSeraph

Thanks! <3
If you make something with my resources, I'll love to take a look at it! :D 